# Problem 3

`sum` was implemented incorrectly, please update with minimum changes. Use **channels**, not **waitGroups**.

# Problem 7

`multiplex` receives values from channels and returns slice of values sorted by which appeared first.

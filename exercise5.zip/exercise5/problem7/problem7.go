package problem7

func multiplex(ch1 <-chan string, ch2 <-chan string) []string {}

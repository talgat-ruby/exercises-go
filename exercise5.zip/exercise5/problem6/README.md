# Problem 6

`piper` combines several operations(pipes). Your job with is to implement `piper` and the pipes. Please check tests

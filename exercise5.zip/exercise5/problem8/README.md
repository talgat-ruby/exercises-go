# Problem 8

`withTimeout` receives a channel and ttl(time to live). If a channel receives message before ttl, send the message,
otherwise send "timeout".

# Exercise 5

Please provide solution for the following problems * is mandatory

1. [problem1](./problem1/README.md) *
2. [problem2](./problem2/README.md)
3. [problem3](./problem3/README.md) *
4. [problem4](./problem4/README.md) *
5. [problem5](./problem5/README.md) *
6. [problem6](./problem6/README.md)
7. [problem7](./problem7/README.md) *
8. [problem8](./problem8/README.md) *
